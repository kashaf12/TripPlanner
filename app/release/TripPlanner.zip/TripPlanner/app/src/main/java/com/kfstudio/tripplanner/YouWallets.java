package com.kfstudio.tripplanner;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Kashaf on 03-03-2018.
 */

public class YouWallets extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.you_wallet);
    }
}
